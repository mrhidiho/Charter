# cpu_worker.py from chat (TLS connect_args added)
