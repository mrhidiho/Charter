import csv
import base64
import os

TEMPLATE = """controller:
  regionName: "{region}"
  geoCode: "{geo}"
  domain: "{domain}"
  image: "controller-https:latest"
  tls:
    cert: "{cert}"
    key: "{key}"
"""

def encode_file_base64(path):
    with open(path, 'rb') as f:
        return base64.b64encode(f.read()).decode('utf-8')

def generate_values_files(csv_file, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    with open(csv_file, newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cert = encode_file_base64(row['tls_crt_path'])
            key = encode_file_base64(row['tls_key_path'])
            values = TEMPLATE.format(
                region=row['region'],
                geo=row['geo'],
                domain=row['domain'],
                cert=cert,
                key=key
            )
            with open(f"{output_dir}/values-{row['region']}.yaml", 'w') as outf:
                outf.write(values)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True, help="Path to CSV file with columns: region,geo,domain,tls_crt_path,tls_key_path")
    parser.add_argument("--out", required=True, help="Directory to write values YAML files")
    args = parser.parse_args()
    generate_values_files(args.csv, args.out)