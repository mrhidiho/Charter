# EKS Geo-Routed Controller Bootstrap

This package provides a reference implementation for deploying SSL-terminating, geo-specific controller services on Amazon EKS using EC2 worker nodes.

---

## 📦 Structure

### `terraform/`
Infrastructure-as-Code using Terraform to:
- Reserve an Elastic IP for the controller.
- Deploy a Network Load Balancer (NLB) that forwards TCP traffic on port 443.
- Attach a Route 53 A-record with geo-routing based on country code.

### `k8s/`
Kubernetes YAML files to:
- Deploy the controller pod (`controller-deployment.yaml`)
- Expose the controller via an NLB with static IP (`controller-service.yaml`)
- Store and mount SSL certs (`controller-secret.yaml`)

### `docker/`
Dockerfile and entrypoint for the controller container:
- Loads SSL certs from `/certs`
- Runs HTTPS server using Python

---

## 🚀 Deployment Guide

### 1. SSL Certificate Setup

Generate or obtain an SSL cert and key.
Encode both in base64 and update `k8s/controller-secret.yaml`:

```
  tls.crt: <base64_cert>
  tls.key: <base64_key>
```

### 2. Build Controller Docker Image

```
cd docker/
docker build -t controller-https:latest .
```

Push this to your container registry of choice (ECR, Docker Hub, etc.).

### 3. Apply Kubernetes Resources

```
kubectl apply -f k8s/
```

### 4. Run Terraform

Update `terraform/variables.tf` with your:
- VPC ID
- Subnet IDs
- AWS region
- Route 53 Zone ID
- Geo-country code
- Domain name

Then run:

```
cd terraform/
terraform init
terraform apply
```

This will output the static public IP of the controller.

---

## ✅ Outcome

You now have:
- A controller pod that terminates SSL at port 443
- Exposed via a public Elastic IP (via NLB)
- DNS entry that routes devices based on location

---

## 🔜 Coming Next

- Helm chart to dynamically template all 880 controller deployments.
- Cert-manager integration for automatic Let's Encrypt certificate provisioning.
- Optional bootstrapper for controller config population.

---

For questions or automation scripts for mass deployment, contact your infrastructure lead or drop this into your GitOps repo.