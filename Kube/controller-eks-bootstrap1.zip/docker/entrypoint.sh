#!/bin/bash
echo "Starting HTTPS controller..."
python3 -m http.server 443 --bind 0.0.0.0 --directory /data --ssl-certfile /certs/tls.crt --ssl-keyfile /certs/tls.key