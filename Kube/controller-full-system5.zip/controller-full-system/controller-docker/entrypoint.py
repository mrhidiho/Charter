from http.server import HTTPServer, BaseHTTPRequestHandler
import ssl
from prometheus_client import start_http_server, Counter

# Define a Prometheus counter metric
REQUESTS = Counter('https_requests_total', 'Total HTTPS Requests')

class HTTPSHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        REQUESTS.inc()
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"Controller OK")

# Start Prometheus metrics server
start_http_server(9100)

# Start HTTPS server
httpd = HTTPServer(('0.0.0.0', 443), HTTPSHandler)
httpd.socket = ssl.wrap_socket(httpd.socket,
                               certfile='/certs/tls.crt',
                               keyfile='/certs/tls.key',
                               server_side=True)

print("Serving HTTPS and metrics on ports 443 and 9100")
httpd.serve_forever()