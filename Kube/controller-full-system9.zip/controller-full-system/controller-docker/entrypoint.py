from http.server import HTTPServer, BaseHTTPRequestHandler
import ssl
from prometheus_client import start_http_server, Counter, Gauge
import os

region = os.getenv("REGION_NAME", "us-west-1")
geohash_map = {'us-west-1': '9q5', 'us-east-1': 'dqc', 'eu-central-1': 'u0x'}
geohash = geohash_map.get(region, "9q5")

REQUESTS = Counter("https_requests_total", "Total HTTPS Requests", ["region", "geohash"])
UP = Gauge("up", "Controller Up Status", ["region", "geohash"])

class HTTPSHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        REQUESTS.labels(region=region, geohash=geohash).inc()
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"Controller OK")

start_http_server(9100)
UP.labels(region=region, geohash=geohash).set(1)

httpd = HTTPServer(("0.0.0.0", 443), HTTPSHandler)
httpd.socket = ssl.wrap_socket(httpd.socket,
                               certfile="/certs/tls.crt",
                               keyfile="/certs/tls.key",
                               server_side=True)

print(f"Serving region: {region}, geohash: {geohash}")
httpd.serve_forever()