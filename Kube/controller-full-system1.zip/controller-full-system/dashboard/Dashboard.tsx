import React, { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const controllers = [
  { region: "us-west-1", ip: "203.0.113.10", status: "Healthy" },
  { region: "us-east-1", ip: "203.0.113.11", status: "Degraded" },
  { region: "eu-central-1", ip: "203.0.113.12", status: "Offline" },
]

export default function Dashboard() {
  const [data, setData] = useState([])

  useEffect(() => {
    // TODO: Replace with real API call
    setData(controllers)
  }, [])

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 p-4">
      {data.map((ctrl) => (
        <Card key={ctrl.region} className="rounded-2xl shadow">
          <CardContent className="p-4 space-y-2">
            <div className="text-xl font-bold">{ctrl.region}</div>
            <div className="text-sm text-muted-foreground">IP: {ctrl.ip}</div>
            <Badge variant={ctrl.status === "Healthy" ? "default" : ctrl.status === "Degraded" ? "warning" : "destructive"}>
              {ctrl.status}
            </Badge>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}