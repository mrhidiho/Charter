
# Overview: Kubernetes + Python Workers + Remote MySQL via ProxySQL

This document gives a high-level picture of the system you’re deploying and how the pieces fit together. It complements the detailed patterns in `docs/patterns.md` and the manifests/code in `k8s/` and `app/`.

## Architecture

![System Architecture](./architecture.png)

**Flow:**

1. **Kafka** buffers inbound events/jobs and provides backpressure.
2. **Async Service Pods** (I/O-bound) consume telemetry/events, batch, and upsert into MySQL.
3. **CPU Worker Pods** (CPU-bound) consume compute jobs, fan out across multiple processes, and write results.
4. **ProxySQL (TLS)** terminates client-side TLS and enforces TLS to MySQL; pools and routes connections (READs to replicas, WRITEs to writer).
5. **MySQL (Writer/Reader)** stores data with appropriate primary keys and indexes for idempotent upserts and fast reads.

## Security & Reliability Pillars

- **TLS Everywhere**
  - App → ProxySQL: CA-verified TLS (`ssl.ca` in SQLAlchemy connect args).
  - ProxySQL → MySQL: `use_ssl=1` with CA/cert/key (optional mTLS).
- **NetworkPolicies**
  - Apps can only egress to ProxySQL:6033, Kafka:9092, and DNS.
  - ProxySQL can only egress to MySQL subnets on 3306 (and DNS).
- **Health Gating**
  - **InitContainer** blocks startup until DB is reachable with TLS.
  - **Sidecar** continuously checks DB reachability; `/db` readiness gates routing.
- **Controlled Rollouts**
  - **PDBs** ensure a minimum of DB-ready pods during voluntary disruptions.
  - **RollingUpdate** with `maxUnavailable: 0`, `maxSurge: 1` preserves capacity.
- **Operational Guardrails**
  - Batching, idempotent upserts, and connection budgets per pod.
  - Optional **KEDA** autoscaling on Kafka lag.

## Deployment Steps (Condensed)

1. **Build & Push Image**
   ```bash
   docker build -t ghcr.io/yourorg/py-stack:1.0.0 .
   docker push ghcr.io/yourorg/py-stack:1.0.0
   ```

2. **Apply Manifests**
   ```bash
   kubectl apply -f k8s/00-namespace.yaml
   kubectl -n apps apply -f k8s/10-secrets-config.yaml
   kubectl -n apps apply -f k8s/21-proxysql-tls.yaml
   kubectl -n apps apply -f k8s/30-migrations-job.yaml
   kubectl -n apps apply -f k8s/40-apps.yaml
   kubectl -n apps apply -f k8s/60-networkpolicies.yaml
   ```

3. **Verify**
   ```bash
   # Sidecar readiness (DB reachability)
   kubectl -n apps port-forward deploy/async-writer 9090:9090
   curl -s localhost:9090/db
   # App liveness
   kubectl -n apps port-forward deploy/async-writer 8080:8080
   curl -s localhost:8080/healthz
   ```

4. **Produce Test Messages**
   ```bash
   # Telemetry path
   echo "router-1,2025-08-29T17:00:00,rx_errors,3" | kafkacat -b kafka:9092 -t telemetry.ingest -P
   # CPU path
   echo "job-123,payload-goes-here" | kafkacat -b kafka:9092 -t jobs.cpu -P
   ```

5. **Rotation & Updates**
   ```bash
   # Rotate TLS secrets
   kubectl -n apps apply -f k8s/21-proxysql-tls.yaml
   kubectl -n apps rollout restart deploy/proxysql
   kubectl -n apps rollout restart deploy/async-writer deploy/cpu-writer
   ```

See `docs/patterns.md` for *why* these choices were made (multiprocessing vs asyncio, batching/upserts, ProxySQL pooling, PDB + rollout strategy, TLS + secret rotation).
