
## Summary

Explain the purpose of this PR. What problem does it solve?

## Changes

- [ ] Code changes
- [ ] Documentation updates
- [ ] Chart updates
- [ ] CI/CD or workflow changes
- [ ] Other (please specify)

## Testing

- [ ] Unit tests added/updated
- [ ] Manual validation in local cluster
- [ ] Helm lint passes locally (`helm lint charts/k8s-mysql-kafka-proxysql`)

## Checklist

- [ ] Secrets not hard-coded, sensitive data handled via Kubernetes Secrets or GitHub Actions secrets.
- [ ] `values.yaml` updated if required, with defaults documented.
- [ ] README/docs updated if required.
- [ ] CI workflow passes.

---

Resolves: # (issue number if applicable)
