
# Summary

> Explain what this PR changes and why. Link related issues.

Closes #<issue-id>

## What changed?

- [ ] Kubernetes manifests
- [ ] Helm chart
- [ ] Application code
- [ ] CI workflow
- [ ] Docs

## Checklist

- [ ] Helm chart lints locally: `helm lint charts/k8s-mysql-kafka-proxysql`
- [ ] Built the image locally: `docker build -t ghcr.io/<org>/py-stack:dev .`
- [ ] Tested deploy in a sandbox namespace
- [ ] Updated docs if necessary

## Screenshots / Logs (optional)

<Add any relevant output>

## Rollout notes

- [ ] Backward-compatible schema changes (if applicable)
- [ ] PDB/rollout strategy preserved (`maxUnavailable: 0`)
- [ ] NetworkPolicies updated if new egress/ingress required
- [ ] TLS secrets rotated if needed
