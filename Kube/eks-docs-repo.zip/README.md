
# Amazon EKS Documentation Repo

This repository contains a structured knowledge set on how Amazon Elastic Kubernetes Service (EKS) works, when to use it, and how it compares with self-managed Kubernetes clusters.

## Contents

- [docs/overview.md](docs/overview.md): What EKS is, architecture, and flow diagrams
- [docs/best-practices.md](docs/best-practices.md): What workloads are best/worst suited, day-1 guidance
- [docs/comparison.md](docs/comparison.md): Comparison of EKS vs kops, kubeadm, and plain EC2 ASGs
- [docs/diagrams/](docs/diagrams/): PNG diagrams (architecture + networking flow)

## Usage

Open the docs folder in GitHub or locally. You can regenerate a package using:

```bash
make package
```

