
# Amazon EKS Overview

Amazon Elastic Kubernetes Service (EKS) is a managed Kubernetes offering from AWS.

## Architecture

![EKS Architecture](diagrams/eks_architecture.png)

The control plane is fully managed by AWS in an AWS-managed VPC, while the data plane (worker nodes) runs in your own VPC. You can run workloads either on EC2 nodes (Managed Node Groups) or on serverless Fargate profiles.

Key elements:
- Multi-AZ managed control plane (API servers, etcd, controllers)
- Worker nodes (EC2) or serverless pods (Fargate)
- AWS VPC CNI for pod networking (pods get routable VPC IPs)
- IAM Pod Identity or IRSA for workload permissions
- Integration with ELB/NLB, EBS/EFS, CloudWatch, etc.

## Flow

![EKS Flow](diagrams/eks_flow.png)

- Clients (kubectl, CI/CD) interact with the API server.
- Scheduler assigns pods to nodes (EC2 or Fargate).
- Pods get VPC IPs; ingress/egress handled by ALB/NLB.
- Pods use IAM Pod Identity/IRSA to access AWS services securely.

