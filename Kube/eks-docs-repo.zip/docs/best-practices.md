
# EKS Best Practices & Workload Fit

## Best suited workloads
- Cloud-native microservices with tight AWS integration
- Data/event streaming workloads that benefit from fast autoscaling
- Regulated/security-sensitive environments (per-pod IAM, SG for Pods)
- Teams wanting minimal ops overhead for the Kubernetes control plane

## Avoid/consider alternatives
- Very small/low-cost clusters where the control-plane hourly fee dominates
- Highly customized control plane needs (custom API server flags, etc.)
- Network models incompatible with AWS VPC CNI
- Heavy DaemonSet use cases if relying only on Fargate

## Day-1 guidance
1. Start with Managed Node Groups + Karpenter for scaling
2. Add Fargate selectively for ops-sensitive workloads
3. Use Pod Identity/IRSA for IAM; one role per service account
4. Enable Security Groups for Pods for sensitive frontends
5. Stay on supported versions; upgrade with EKS-managed add-ons
