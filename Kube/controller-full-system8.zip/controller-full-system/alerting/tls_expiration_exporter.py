import ssl
import socket
from prometheus_client import start_http_server, Gauge
import time

TLS_DAYS_LEFT = Gauge('tls_days_until_expiration', 'Days until TLS cert expires')

def check_cert_expiry(host, port=443):
    context = ssl.create_default_context()
    conn = context.wrap_socket(socket.socket(socket.AF_INET), server_hostname=host)
    conn.settimeout(5.0)
    conn.connect((host, port))
    cert = conn.getpeercert()
    expires = ssl.cert_time_to_seconds(cert['notAfter'])
    days = (expires - time.time()) / 86400
    TLS_DAYS_LEFT.set(days)
    conn.close()

if __name__ == "__main__":
    start_http_server(9111)
    target_host = "localhost"
    while True:
        try:
            check_cert_expiry(target_host)
        except Exception as e:
            print(f"Error checking cert: {e}")
            TLS_DAYS_LEFT.set(0)
        time.sleep(3600)