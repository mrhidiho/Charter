# Full EKS Geo-Controller Deployment System

This repository contains everything needed to deploy 880+ geo-routed controllers to AWS EKS using:

- **Helm charts** for Kubernetes controller deployment
- **Terraform modules** for NLB, EIP, and Route 53 setup
- **Docker-based HTTPS controller**
- **GitHub Actions CI/CD workflow**
- **CSV to values.yaml generator**

## 📁 Structure

- `helm/` — Helm chart and generator script
- `terraform/` — Infra provisioning for all controllers
- `controller-docker/` — HTTPS controller container image
- `.github/workflows/` — CI/CD deployment pipeline

## ✅ Deployment Steps

1. **Build and push Docker image**
2. **Run Terraform with your list of controller regions**
3. **Use generator script to create `values-*.yaml` for Helm**
4. **Deploy with Helm or use GitHub Actions**

---

Make sure you have cert-manager installed in your cluster if using Let's Encrypt integration.